Vanadine Regular and Bold
-----------------------------------------------
This is free for your creations.
Note : Contain Alternates of Letters.
Please look tuts.png for uses.
-----------------------------------------------
Suitable for free or comercial uses.
